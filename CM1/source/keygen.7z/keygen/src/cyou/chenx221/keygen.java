package cyou.chenx221;

import java.util.Base64;
import java.util.Scanner;

public class keygen {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string to encode in Base64 (Name): ");
        String input = scanner.nextLine();
        String encoded = Base64.getEncoder().encodeToString(input.getBytes());
        System.out.println("Base64 Encoded (SN): " + encoded);
        scanner.close();
    }
}
