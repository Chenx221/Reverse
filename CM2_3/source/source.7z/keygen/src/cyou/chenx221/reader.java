package cyou.chenx221;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class reader {
    public static void main(String[] args) {
        try {
            InputStream var0 = new FileInputStream("C:\\work\\I.gif");
            int var1 = var0.read() << 16 | var0.read() << 8 | var0.read();
            byte[] IYOE = new byte[var1];
            int var2 = 0;
            byte var3 = (byte)var1;

            while(var1 != 0) {
                int var5 = var0.read(IYOE, var2, var1);
                if (var5 == -1) {
                    break;
                }

                var1 -= var5;

                for(int var7 = var5 + var2; var2 < var7; ++var2) {
                    IYOE[var2] ^= var3;
                }
            }

            var0.close();
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
