package cyou.chenx221;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.zip.CRC32;

public class keygen {
    public static void main(String[] args) throws NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Name: ");
        String name = scanner.nextLine();
        String text = "vhly[FR]" + name;
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(text.getBytes());
        CRC32 crc32 = new CRC32();
        crc32.update(digest);
        long crcValue = crc32.getValue();
        System.out.printf("SN: %s%n", Long.toString(crcValue, 36));

        scanner.close();
    }
}
